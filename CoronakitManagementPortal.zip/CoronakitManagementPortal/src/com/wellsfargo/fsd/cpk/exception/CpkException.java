package com.wellsfargo.fsd.cpk.exception;

public class CpkException extends Exception {

	public CpkException(String errMsg) {
		super(errMsg);
		
	}

}
